import { createContext, useReducer } from "react"

 

let CartReducer=(state,action)=>{
    switch(action.type)
    {
        case 'addtocart': return { cart: [...state.cart, action.payload]}
    }
}

let CartContext=createContext()
export let cartProvider=({children})=>
         {
let [state, dispatch]=useReducer(CartReducer, {cart: []})
    return(<>
    <CartContext.Provider value={{state, dispatch}}>
        {children}
    </CartContext.Provider>
    </>)
}
export default CartContext