import React from 'react'
import Link from 'next/link'
import DashboardLayout from '../components/DashboardLayout'
import AdminProtectedRoute from '../components/AdminProtectedRoute'

function page() {
  return (
    <div>
      
        <DashboardLayout>
      
      </DashboardLayout>
      
    </div>
  )
}

export default page
