"use client";

import Layout from "@/app/components/Layout";
import { useParams } from "next/navigation";
import React, { useEffect, useState } from "react";
import Link from "next/link";

function Page() {
  const { cid } = useParams();
  const [products, setProducts] = useState([]);

  useEffect(() => {
    if (!cid) return;
    fetch(`/api/products?category=${cid}`)
      .then((res) => res.json())
      .then((data) => setProducts(data));
  }, [cid]);

  const handleAddToCart = (product) => {
    console.log("Add to cart:", product);
    // You can integrate with context/localStorage here
  };

  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6 capitalize text-gray-800">
          Category: {cid}
        </h1>

        {products.length === 0 ? (
          <p className="text-gray-500">No products found.</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {products.map((product) => (
              <div
                key={product._id}
                className="bg-white border rounded-lg shadow-sm hover:shadow-md transition overflow-hidden flex flex-col"
              >
                <Link href={`/product/${product._id}`}>
                  <img
                    src={product.image}
                    alt={product.title}
                    className="h-48 w-full object-cover hover:scale-105 transition-transform duration-300"
                  />
                </Link>
                <div className="p-4 flex-1 flex flex-col">
                  <h2 className="text-lg font-semibold text-gray-800 mb-1">
                    {product.title}
                  </h2>
                  <p className="text-gray-600 text-sm mb-3">Rs. {product.price}</p>
                  
                  <div className="mt-auto">
                    <button
                      onClick={() => handleAddToCart(product)}
                      className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 transition"
                    >
                      Add to Cart
                    </button>
                    <Link
                      href={`/product/${product._id}`}
                      className="block mt-2 text-center text-sm text-blue-600 hover:underline"
                    >
                      View Details
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
}

export default Page;
