import React from 'react'
import Header from '../components/Header'
import Layout from '../components/Layout'

function page() {
  return (
    <div>
      <Layout>
        
      </Layout>
    </div>
  )
}

export default page
